import java.util.Map;

import android.app.Activity;
import android.content.Context;
import com.mopub.mobileads.CustomEventInterstitial;
import com.mopub.mobileads.MoPubErrorCode;
import com.smaato.soma.interstitial.Interstitial;
import com.smaato.soma.interstitial.InterstitialAdListener;

/**
 * Example of MoPub Smaato Interstitial mediation adapter.
 * @author Chouaieb Nabil
 */
public class SomaMopubAdapterInterstitial extends CustomEventInterstitial implements InterstitialAdListener {

	private Interstitial interstitial;
	private CustomEventInterstitialListener customEventInterstitialListener;

	@Override
	protected void loadInterstitial(Context context,
			CustomEventInterstitialListener customEventInterstitialListener, Map<String, Object> localExtras,
			Map<String, String> serverExtras) {
			this.customEventInterstitialListener =customEventInterstitialListener;
			if(interstitial == null){
				interstitial = new Interstitial((Activity) context);
				interstitial.setInterstitialAdListener(this);
			}
			int publisherId = Integer.parseInt((String) serverExtras.get("publisherId"));
			int adSpaceId = Integer.parseInt((String) serverExtras.get("adSpaceId"));
			interstitial.getAdSettings().setPublisherId(publisherId);
			interstitial.getAdSettings().setAdspaceId(adSpaceId);
			interstitial.asyncLoadNewBanner();
	}

	@Override
	protected void onInvalidate() {
		// TODO Auto-generated method stub
	}

	@Override
	protected void showInterstitial() {
		interstitial.show();
	}

	@Override
	public void onFailedToLoadAd() {
		customEventInterstitialListener.onInterstitialFailed(MoPubErrorCode.NO_FILL);
	}

	@Override
	public void onReadyToShow() {
		customEventInterstitialListener.onInterstitialLoaded();
		showInterstitial();
	}

	@Override
	public void onWillClose() {
		customEventInterstitialListener.onInterstitialDismissed();
	}

	@Override
	public void onWillOpenLandingPage() {
		customEventInterstitialListener.onInterstitialClicked();
	}

	@Override
	public void onWillShow() {
		customEventInterstitialListener.onInterstitialShown();
	}

}
