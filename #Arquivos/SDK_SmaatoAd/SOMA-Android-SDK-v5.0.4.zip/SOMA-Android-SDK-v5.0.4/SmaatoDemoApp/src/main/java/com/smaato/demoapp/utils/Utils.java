package com.smaato.demoapp.utils;

import android.app.Activity;
import android.content.res.Resources;
import android.util.TypedValue;

public class Utils {
	private static Utils instance;

	private Utils() {
	}

	public static Utils getInstance() {
		if (instance == null) {
			instance = new Utils();
		}
		return instance;
	}

	public float pixelsToDp(final float pixels, Activity activity) {
		Resources r = activity.getResources();
		float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, pixels,
				r.getDisplayMetrics());
		return px;
	}

}
