package com.smaato.demoapp;

import android.app.Activity;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class CustomList extends ArrayAdapter<String> {
	private final Activity context;
	private final String[] text;
	private final Integer[] imageId;
	//private final String [] colors = {"#F16745","#FFC65D","#7BC8A4","#4CC3D9","#93648D","#404040"};
private final boolean isMainMenu;
	
	public CustomList(Activity context, String[] text, Integer[] imageId,boolean isMainMenu) {
		super(context, R.layout.list_single, text);
		this.context = context;
		this.text = text;
		this.imageId = imageId;
		this.isMainMenu = isMainMenu;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		LayoutInflater inflater = context.getLayoutInflater();
		View rowView;
		if(!isMainMenu){
			rowView = inflater.inflate(R.layout.config_list, null, true);
		}
		else {
			rowView = inflater.inflate(R.layout.list_single, null, true);
		}
		TextView txtTitle = (TextView) rowView.findViewById(R.id.txt);
		ImageView imageView = (ImageView) rowView.findViewById(R.id.img);
		txtTitle.setText(text[position]);
		if(!isMainMenu){
			txtTitle.setTextColor(Color.parseColor("#FFFFFF"));
			txtTitle.setBackgroundColor(Color.parseColor("#4c4c4c"));
			imageView.setBackgroundColor(Color.parseColor("#424242"));
			((RelativeLayout)imageView.getParent()).setBackgroundColor(Color.parseColor("#424242"));
		} else{
			txtTitle.setTextColor(Color.parseColor("#686868"));
			txtTitle.setBackgroundColor(Color.parseColor("#ECF0F1"));
			imageView.setBackgroundColor(Color.parseColor("#E6e6e6"));
			((RelativeLayout)imageView.getParent()).setBackgroundColor(Color.parseColor("#E6e6e6"));
		}
		imageView.setImageResource(imageId[position]);
		return rowView;
	}
}
