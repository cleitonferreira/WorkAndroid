package com.smaato.demoapp.activities;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.smaato.demoapp.R;
import com.smaato.demoapp.recyclerview.CustomAdapter;
import com.smaato.demoapp.recyclerview.DataItem;
import com.smaato.demoapp.utils.Constants;
import com.smaato.soma.AdDownloaderInterface;
import com.smaato.soma.AdListenerInterface;
import com.smaato.soma.ErrorCode;
import com.smaato.soma.ReceivedBannerInterface;
import com.smaato.soma.exception.AdReceiveFailed;
import com.smaato.soma.nativead.NativeAd;

public class NativeAdChatRecyclerViewSample extends Activity implements OnClickListener,
		AdListenerInterface {
	NativeAd nativeAd;
	RelativeLayout nativeRelativeLayout;
	RelativeLayout nativeRelativeLayout2;
	NativeAd nativeAd2;

	Button reloadBanner;

	private static final int DATASET_COUNT = 10;


	protected RecyclerView mRecyclerView;
	protected CustomAdapter mAdapter;
	protected RecyclerView.LayoutManager mLayoutManager;
	protected DataItem[] mDataset;


	static String TAG= NativeAdChatRecyclerViewSample.class.getSimpleName();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// TODO
		setContentView(R.layout.recycler_view_frag);
		initDataset();

		mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
		mLayoutManager = new LinearLayoutManager(this);

		// set the layout
		setRecyclerViewLayoutManager();

		mAdapter = new CustomAdapter(mDataset);
		// setting customAdapter as the Adapter for the RecylcerView
		mRecyclerView.setAdapter(mAdapter);


		reloadBanner = (Button) findViewById(R.id.angry_btn);
/*		reloadBanner.setOnClickListener(NativeAdChatRecyclerViewSample.this);
		nativeAd = new NativeAd(this);
		nativeAd.setAdListener(NativeAdChatRecyclerViewSample.this);
		nativeRelativeLayout = (RelativeLayout) findViewById(R.id.nativeAdLayout);


		SharedPreferences prefs = NativeAdChatRecyclerViewSample.this.getSharedPreferences(Constants.COM_SMAATO_DEMOAPP,
				Context.MODE_PRIVATE);
		nativeAd.getAdSettings().setPublisherId(Integer.parseInt(prefs.getString(Constants.COM_SMAATO_DEMOAPP + Constants.PUBLISHER_ID, "0")));
		nativeAd.getAdSettings().setAdspaceId(Integer.parseInt(prefs.getString(Constants.COM_SMAATO_DEMOAPP + Constants.AD_SPACE_ID, "0")));
		nativeAd.setMainLayout(nativeRelativeLayout);

		nativeAd2 = new NativeAd(this);
		nativeRelativeLayout2 = (RelativeLayout) findViewById(R.id.nativeAdLayout2);

		nativeAd2.setAdListener(new AdListenerInterface() {
			@Override
			public void onReceiveAd(AdDownloaderInterface sender, ReceivedBannerInterface receivedBanner) throws AdReceiveFailed {
				if (receivedBanner.getErrorCode() != ErrorCode.NO_ERROR) {
					Toast.makeText(getApplicationContext(), "2nd Req failed" + receivedBanner.getErrorMessage(), Toast.LENGTH_SHORT).show();
					}
			}
		});


		nativeAd2.getAdSettings().setPublisherId(Integer.parseInt(prefs.getString(Constants.COM_SMAATO_DEMOAPP + Constants.PUBLISHER_ID, "0")));
		nativeAd2.getAdSettings().setAdspaceId(Integer.parseInt(prefs.getString(Constants.COM_SMAATO_DEMOAPP + Constants.AD_SPACE_ID, "0")));
		nativeAd2.setMainLayout(nativeRelativeLayout2);

		requestNewAd();
		requestNewSecondAd();*/

	}

	@Override
	public void onClick(View v) {
		requestNewAd();
	}

	public void requestNewAd() {
		nativeAd.asyncLoadNativeType(NativeAd.NativeType.CHAT_LIST, nativeAdTypeListener);
	}



	NativeAd.NativeAdTypeListener nativeAdTypeListener = new NativeAd.NativeAdTypeListener() {
		@Override
		public void onError(ErrorCode errorCode, String errorMessage) {
			Log.e(TAG, "" + errorCode + " " + errorMessage);
		}

		@Override
		public void onAdResponse(ViewGroup nativeView) {
			if (nativeView != null) {
				Log.d(TAG, "Layout view received & Added for NativeAd_1");
				// IMPORTANT step to be invoked after attaching ad response to Screen.
				// IMPORTANT FOR IMPRESSIONS COUNTS
				nativeAd.bindAdResponse(nativeView);
			}
		}
	};

	public void requestNewSecondAd() {

		nativeAd2.asyncLoadNativeType(NativeAd.NativeType.CHAT_LIST, new NativeAd.NativeAdTypeListener() {
			@Override
			public void onError(ErrorCode errorCode, String errorMessage) {
				Log.e(TAG, "" + errorCode + " " + errorMessage);
			}

			@Override
			public void onAdResponse(ViewGroup nativeView) {
				if (nativeView != null) {
					// IMPORTANT step to be invoked after attaching ad response to Screen.
					// IMPORTANT FOR IMPRESSIONS COUNTS
					nativeAd2.bindAdResponse(nativeView);
				}
			}
		});

	}

	/**
	 * Set RecyclerView's LayoutManager
	 */
	public void setRecyclerViewLayoutManager() {
		int scrollPosition = 0;

		// If a layout manager has already been set, get current scroll position.
		if (mRecyclerView.getLayoutManager() != null) {
			scrollPosition = ((LinearLayoutManager) mRecyclerView.getLayoutManager())
					.findFirstCompletelyVisibleItemPosition();
		}

		mLayoutManager = new LinearLayoutManager(this);
		mRecyclerView.setLayoutManager(mLayoutManager);
		mRecyclerView.scrollToPosition(scrollPosition);
	}

	private void initDataset() {
		mDataset = new DataItem[DATASET_COUNT];

		DataItem dataItem;

		for (int i = 0; i < DATASET_COUNT; i++) {
			dataItem = new DataItem();
			mDataset[i] = dataItem;

			mDataset[i].setTitle("This is tille #" + i);
			mDataset[i].setDesc("This is desc #" + i);
			if(i%2==0){
				mDataset[i].setImageURL(R.drawable.native1icon);
			} else {
				mDataset[i].setImageURL(R.drawable.native2icon);
			}

		}
	}

	// only for first NativeAd
	@Override
	public void onReceiveAd(AdDownloaderInterface sender,
							ReceivedBannerInterface receivedBanner) throws AdReceiveFailed {
		if (receivedBanner.getErrorCode() != ErrorCode.NO_ERROR) {
			Toast.makeText(getApplicationContext(),
					receivedBanner.getErrorMessage(), Toast.LENGTH_LONG).show();
		}
	}
}