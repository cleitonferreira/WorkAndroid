package com.smaato.demoapp.utils;

public class Constants {
	public static final String COM_SMAATO_DEMOAPP = "com.smaato.demoapp";

	public static final String PUBLISHER_ID = "PUBLISHER_ID";	
	public static final String AD_SPACE_ID = "AD_SPACE_ID";
	public static final String REFRESH_AD = "REFRESH_AD";
	public static final String REFRESH_INTERVAL = "REFRESH_INTERVAL";
	public static final String GPS = "GPS";
	private Constants (){}

}
