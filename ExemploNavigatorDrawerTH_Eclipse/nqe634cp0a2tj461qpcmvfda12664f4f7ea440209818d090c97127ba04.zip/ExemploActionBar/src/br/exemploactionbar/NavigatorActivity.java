package br.exemploactionbar;

import java.util.ArrayList;
import java.util.List;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.view.ActionProvider;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.SubMenu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class NavigatorActivity extends SherlockFragmentActivity implements ListView.OnItemClickListener {
	private ActionBar ab;
	private DrawerLayout dl;
	private ListView lv;
	private ActionBarDrawerToggle tg;
	
	private List<String> fragments;
	private CharSequence tl;
	private CharSequence tlf;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_navigator);
		
		tl = tlf = getTitle();
		
		ab = getSupportActionBar();
		ab.setDisplayHomeAsUpEnabled(true);
		ab.setHomeButtonEnabled(true);
		
		fragments = new ArrayList<String>();
		fragments.add("Fragment 1");
		fragments.add("Fragment 2");
		fragments.add("Fragment 3");
		
		lv = (ListView) findViewById(R.id.lv);
		lv.setAdapter(new MyAdapter(this, fragments));
		lv.setOnItemClickListener(this);
		
		dl = (DrawerLayout) findViewById(R.id.dl);
		
		tg = new ActionBarDrawerToggle(this, dl, R.drawable.toggle_img, R.string.title_activity_activity1, R.string.title_activity_activity2){
			public void onDrawerClosed(View view){
				ab.setTitle(tl);
				supportInvalidateOptionsMenu();
			}
			public void onDrawerOpened(View view){
				ab.setTitle(tlf);
				supportInvalidateOptionsMenu();
			}
		};
		dl.setDrawerListener(tg);
		
		if(savedInstanceState == null){
			selectedItem(0);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getSupportMenuInflater().inflate(R.menu.navigator, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		
		boolean status = dl.isDrawerOpen(lv);
		menu.findItem(R.id.action_settings).setVisible(!status);
		
		return super.onPrepareOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem mi) {
		if(tg.onOptionsItemSelected(getCorrectMenuItem(mi))){
			return(true);
		}
		return super.onOptionsItemSelected(mi);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		selectedItem(position);
	}
	
	
	private void selectedItem(int position){
		FragmentTransaction ft;
		Fragment frag;
		
		switch(position){
			case 0:
				frag = new Fragment1();
				ft = getSupportFragmentManager().beginTransaction();
				ft.replace(R.id.fl, frag);
				ft.commit();
				break;
			case 1:
				frag = new Fragment2();
				ft = getSupportFragmentManager().beginTransaction();
				ft.replace(R.id.fl, frag);
				ft.commit();
				break;
			default:
				frag = new Fragment3();
				ft = getSupportFragmentManager().beginTransaction();
				ft.replace(R.id.fl, frag);
				ft.commit();
				break;
		}
		
		lv.setItemChecked(position, true);
		setCustomTitle(fragments.get(position));
		dl.closeDrawer(lv);
	}
	
	
	private void setCustomTitle(String title){
		ab.setTitle(title);
		tl = title;
	}
	
	
	@Override
	protected void onPostCreate(Bundle savedInstanceState){
		super.onPostCreate(savedInstanceState);
		
		tg.syncState();
	}
	
	
	private android.view.MenuItem getCorrectMenuItem(final MenuItem mi){
		return(new android.view.MenuItem(){
			@Override
			public boolean collapseActionView() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean expandActionView() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public ActionProvider getActionProvider() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public View getActionView() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public char getAlphabeticShortcut() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public int getGroupId() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public Drawable getIcon() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Intent getIntent() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public int getItemId() {
				// TODO Auto-generated method stub
				return mi.getItemId();
			}

			@Override
			public ContextMenuInfo getMenuInfo() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public char getNumericShortcut() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public int getOrder() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public SubMenu getSubMenu() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public CharSequence getTitle() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public CharSequence getTitleCondensed() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public boolean hasSubMenu() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isActionViewExpanded() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isCheckable() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isChecked() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isEnabled() {
				// TODO Auto-generated method stub
				return true;
			}

			@Override
			public boolean isVisible() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public android.view.MenuItem setActionProvider(ActionProvider arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setActionView(View arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setActionView(int arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setAlphabeticShortcut(char arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setCheckable(boolean arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setChecked(boolean arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setEnabled(boolean arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setIcon(Drawable arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setIcon(int arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setIntent(Intent arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setNumericShortcut(char arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setOnActionExpandListener(
					OnActionExpandListener arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setOnMenuItemClickListener(
					OnMenuItemClickListener arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setShortcut(char arg0, char arg1) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public void setShowAsAction(int arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public android.view.MenuItem setShowAsActionFlags(int arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setTitle(CharSequence arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setTitle(int arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setTitleCondensed(CharSequence arg0) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public android.view.MenuItem setVisible(boolean arg0) {
				// TODO Auto-generated method stub
				return null;
			}
			
		});
	}

}
