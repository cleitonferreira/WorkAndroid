/** Automatically generated file. DO NOT MODIFY */
package br.exemplogcm;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}